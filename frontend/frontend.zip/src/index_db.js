import express from 'express'
const app2 = express()

app2.listen(8800, () => {
    console.log("connected to backend")
})

