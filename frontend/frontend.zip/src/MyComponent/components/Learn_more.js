import React from 'react';
import './Learn_more.css';
import '../../font.css';

const Learn_more = () => {
    
    return (
        <>
            <div class="content">
                <h2 class="text_shadows">Project made by <br></br> Nayan 2021402 <br></br>Navnoor 2021401</h2>
            </div>
        </>
 
    )
}

export default Learn_more;
